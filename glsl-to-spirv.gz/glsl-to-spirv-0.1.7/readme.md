This crate is deprecated please use [shaderc-rs](https://github.com/google/shaderc-rs) instead.
